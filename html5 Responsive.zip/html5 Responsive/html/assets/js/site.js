(function ($) {	   
		// alert(0)
})(jQuery);

